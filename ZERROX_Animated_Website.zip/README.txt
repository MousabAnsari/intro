# ZERROX Animated Website

Open `index.html` in a browser.

Everything is in one HTML file:
- Responsive mobile + desktop layout
- Animated background particles
- Animated hero, cards, buttons and scroll reveals
- Mobile hamburger menu
- Smooth scrolling
- Telegram + Instagram buttons
- No external libraries required

To edit text/links, open `index.html` and search for the text you want to change.
